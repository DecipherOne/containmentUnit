from harstorage.tests import *

class TestMigrationController(TestController):

    def test_index(self):
        pass